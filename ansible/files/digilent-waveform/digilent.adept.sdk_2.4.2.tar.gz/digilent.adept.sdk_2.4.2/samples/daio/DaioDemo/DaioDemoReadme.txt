Module Description:
	DAIO Demo is a project to demonstrate how to measure an
	analog input voltage using the DAIO Module of the Adept
	SDK and an I/O Explorer board.							
	
Hardware Setup:														
	On the I/O Explorer, attatch leads from AIN0 to the terminals
	of a AA battery. 