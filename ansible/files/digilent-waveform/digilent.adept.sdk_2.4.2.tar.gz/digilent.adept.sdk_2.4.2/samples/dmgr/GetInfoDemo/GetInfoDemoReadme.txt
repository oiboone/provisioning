Module Description:
	Get Info Demo is a project to demonstrate how to get
	information regarding a connected device using the DMGR
	module of the Adept SDK.

Hardware Setup:
	Specify the name of a connected device as a
	command line argument.