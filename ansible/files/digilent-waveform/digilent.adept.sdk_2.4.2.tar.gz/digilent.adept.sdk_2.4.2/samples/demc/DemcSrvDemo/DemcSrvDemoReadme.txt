Module Description: 
	Demc Servo Demo demonstrates use of the servo functions in the DEMC
	interface of the Digilent Adept 2 system using the I/O Explorer	
	board.

Hardware Setup:
	Connect servo motors to servo connectors 1 - 4 on the 
	I/O Explorer. To control more or less servos, you can modify
	the cServos constant in the source.