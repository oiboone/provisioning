Module Description:
	This project illustrates using the pin I/O API functions in the DPIO
	interface in the Digilent Adept system being used with an I/O
	Explorer board.	


Hardware Setup:
	This demo project assumes that there are Digilent Pmod8LD modules
	connected to Pmod connectors JA-JE on the I/O Explorer board. If
	this isn't the case, the demo will still run, there just won't be
	any discernable operation until the end of the demo where it runs
	a loop reading the swtiches, buttons and dip switches and echos	
	the state out to the LEDs.	