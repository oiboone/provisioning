Module Description: 										
	DACI Demo is a project designed to demonstrate how	
	to send and recieve data asynchronously on an I/O	
	Explorer board using the DACI module of the Adept SDK.

Hardware Setup:													
	Connect the I/O Explorer to the PC via USB. Short the TXD1 and
	RXD1 pins on connector JG for this loopback demo.